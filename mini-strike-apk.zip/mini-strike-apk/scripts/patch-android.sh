#!/usr/bin/env bash
# Делает приложение полноэкранным и альбомным после `cap add android`.
set -euo pipefail
MANIFEST=android/app/src/main/AndroidManifest.xml
STYLES=android/app/src/main/res/values/styles.xml

grep -q 'screenOrientation' "$MANIFEST" || sed -i 's#<activity#<activity android:screenOrientation="sensorLandscape"#' "$MANIFEST"

python3 - "$STYLES" <<'PY'
import sys,re
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
extra='''        <item name="android:windowFullscreen">true</item>
        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>
'''
if 'windowFullscreen' not in s:
    s=re.sub(r'(<style name="AppTheme\.NoActionBar"[^>]*>\s*\n)',lambda m:m.group(1)+extra,s,count=1)
open(p,'w',encoding='utf-8').write(s)
PY
echo patched
